/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'fo', {
	button: 'Skabelónir',
	emptyListMsg: '(Ongar skabelónir tøkar)',
	insertOption: 'Yvirskriva núverandi innihald',
	options: 'Møguleikar fyri Template',
	selectPromptMsg: 'Vinarliga vel ta skabelón, ið skal opnast í tekstviðgeranum<br>(Hetta yvirskrivar núverandi innihald):',
	title: 'Innihaldsskabelónir'
} );
