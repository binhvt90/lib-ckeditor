/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'sr-latn', {
	button: 'Obrasci',
	emptyListMsg: '(Nema definisanih obrazaca)',
	insertOption: 'Replace actual contents', // MISSING
	options: 'Template Options', // MISSING
	selectPromptMsg: 'Molimo Vas da odaberete obrazac koji ce biti primenjen na stranicu (trenutni sadržaj ce biti obrisan):',
	title: 'Obrasci za sadržaj'
} );
