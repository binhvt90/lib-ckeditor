/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'pl', {
	button: 'Szablony',
	emptyListMsg: '(Brak zdefiniowanych szablonów)',
	insertOption: 'Zastąp obecną zawartość',
	options: 'Opcje szablonów',
	selectPromptMsg: 'Wybierz szablon do otwarcia w edytorze<br>(obecna zawartość okna edytora zostanie utracona):',
	title: 'Szablony zawartości'
} );
