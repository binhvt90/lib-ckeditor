﻿/*
Its The Persian (Farsi) Language Translate For Iranian By "Mohsen Esmaili"
*/
CKEDITOR.plugins.setLang('wordcount', 'fa', {
    WordCount: 'لغت:',
    CharCount: 'کاراکتر:',
    CharCountWithHTML: 'کاراکترها (با HTML):',
    Paragraphs: 'پاراگراف:',
    ParagraphsRemaining: 'Paragraphs remaining',
    pasteWarning: 'محتوای مورد نظر را نمی توان چسباند. زیرا این بیشتر از حد مجاز است.',
    Selected: 'انتخاب شده: ',
    title: 'آمار'
});