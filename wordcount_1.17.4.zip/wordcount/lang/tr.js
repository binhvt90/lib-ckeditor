﻿/*
Mesut ÇAKIR
mesut.cakir@hotmail.com.tr
*/
CKEDITOR.plugins.setLang('wordcount', 'tr', {
    WordCount: 'Kelime:',
    CharCount: 'Karakter:',
    CharCountWithHTML: 'Karakter (HTML dahil):',
    Paragraphs: 'Paragraf:',
    ParagraphsRemaining: 'Paragraphs remaining',
    pasteWarning: 'Content can not be pasted because it is above the allowed limit',
    Selected: 'Selected: ',
    title: 'İstatistik'
});
