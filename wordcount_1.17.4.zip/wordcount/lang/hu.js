﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang('wordcount', 'hu', {
    WordCount: 'Szavak:',
    CharCount: 'Karakaterek:',
    CharCountWithHTML: 'Karakterek (HTML tagekkel):',
    Paragraphs: 'Bekezdések:',
    ParagraphsRemaining: 'Paragraphs remaining',
    pasteWarning: 'A szöveget nem lehet beilleszteni, mert a megadott limit felett van',
    Selected: 'Kiválasztva: ',
    title: 'Statisztika'
});
